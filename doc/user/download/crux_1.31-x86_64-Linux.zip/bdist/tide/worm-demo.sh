#!/bin/sh
./tide-index --fasta=worm.fasta --enzyme=trypsin --digestion=full-digest
./tide-import-spectra --in=worm-06-10000.ms2 -out=worm-06-10000.spectrumrecords
./tide-search --peptides=worm.fasta.pepix --proteins=worm.fasta.protix \
              --spectra=worm-06-10000.spectrumrecords  > worm.results
